from django.apps import AppConfig


class StudentTaskConfig(AppConfig):
    name = 'student_task'
