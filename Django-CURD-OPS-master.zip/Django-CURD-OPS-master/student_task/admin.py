from django.contrib import admin
from student_task.models import student
# Register your models here.

admin.site.register(student)
